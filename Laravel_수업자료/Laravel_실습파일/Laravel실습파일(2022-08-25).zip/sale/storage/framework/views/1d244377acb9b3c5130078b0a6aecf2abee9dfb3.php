
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">제품사진</div>

	<script>
		function find_text()
		{
			form1.action="<?php echo e(route('picture.index')); ?>";
			form1.submit();
		}

		function zoomimage( iname, pname )
		{
			w=window.open("<?php echo e(url('picture/zoom')); ?>?iname=" + iname + "&pname=" + pname ,
				"imageview","resizable=yes,scrollbars=yes,status=no,width=800,height=600");
			w.focus();
		}		
	</script>

	<form name="form1" action="">
	<div class="row">
		<div class="col-3" align="left">
			<div class="input-group input-group-sm">
				<span class="input-group-text">이름</span>
				<input type="text" name="text1" value="<?php echo e($text1); ?>" class="form-control" 
					onKeydown="if (event.keyCode == 13) { find_text(); }"> 
				<button class="btn mycolor1" type="button" 
					onClick="find_text();">검색</button>
			</div>
		</div>
		<div class="col-9" align="right">
		</div>
	</div>
	</form>

	<div class="row">
		<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?
			$iname=$row->pic ? $row->pic : "";
			$pname=$row->name;
	?>
			<div class="col-3">
				<div class="mythumb_box"">
					<img src="<?php echo e(asset('/storage/product_img/thumb/' . $iname)); ?>" class="mythumb_image" style="cursor:pointer"  data-bs-toggle="modal" data-bs-target="#zoomModal" onclick="document.getElementById('zoomModalLabel').innerText='<?php echo e($pname); ?>'; picname.src='<?php echo e(asset('/storage/product_img/' . $iname)); ?>'">
					<div class="mythumb_text"><?php echo e($pname); ?></div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<?php echo e($list->links( 'mypagination' )); ?>


<?php $__env->stopSection(); ?>

<!-- Zoom Modal 이미지 -->
<div class="modal fade" id="zoomModal" tabindex="-1" aria-labelledby="zoomModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-xl">
		<div class="modal-content">
			<div class="modal-header bg-light">
				<h5 class="modal-title" id="zoomModalLabel">상품명1</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" align="center">
				<img src="#" name="picname" class="img-fluid img-thumbnail" style="cursor:pointer" data-bs-dismiss="modal">
			</div>
		</div>
	</div>
</div>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/picture/index.blade.php ENDPATH**/ ?>