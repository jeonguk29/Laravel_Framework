
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">매입</div>

	<form name="form1" method="post" action="">

	<table class="table table-sm table-bordered mymargin5">
		<tr>
			<td width="20%" class="mycolor2">번호</td>
			<td width="80%" align="left"><?php echo e($row->id); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 날짜</td>
			<td width="80%" align="left"><?php echo e($row->writeday); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 제품명</td>
			<td width="80%" align="left"><?php echo e($row->product_name); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">단가</td>
			<td width="80%" align="left"><?php echo e(number_format($row->price)); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">수량</td>
			<td width="80%" align="left"><?php echo e(number_format($row->numi)); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">금액</td>
			<td width="80%" align="left"><?php echo e(number_format($row->prices)); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">비고</td>
			<td width="80%" align="left"><?php echo e($row->bigo); ?></td>
		</tr>
	</table>

	<div align="center">
		<a href="<?php echo e(route('jangbui.edit', $row->id)); ?><?php echo e($tmp); ?>" class="btn btn-sm mycolor1">수정</a>
		<form action="<?php echo e(route('jangbui.destroy', $row->id)); ?>">
			<?php echo csrf_field(); ?>
			<?php echo method_field('DELETE'); ?>
			<button type="submit" class="btn btn-sm mycolor1" 
				onClick="return confirm('삭제할까요 ?');">삭제</button> &nbsp;
		</form>
		<input type="button" value="이전화면" class="btn btn-sm mycolor1" onClick="history.back();">
	</div>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/jangbui/show.blade.php ENDPATH**/ ?>