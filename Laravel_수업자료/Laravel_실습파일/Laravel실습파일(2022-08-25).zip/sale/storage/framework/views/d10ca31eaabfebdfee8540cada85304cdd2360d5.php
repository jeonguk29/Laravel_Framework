
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">BEST 제품</div>

	<script>
		function find_text()
		{
			form1.action="<?php echo e(route('best.index')); ?>";
			form1.submit();
		}

		$(function() 
		{ 
			$("#text1") .datetimepicker({ 
				locale: "ko", 
				format: "YYYY-MM-DD" 
			}); 
			$("#text2") .datetimepicker({ 
				locale: "ko", 
				format: "YYYY-MM-DD" 
			});

			$("#text1") .on("dp.change", function (e) {	find_text(); });
			$("#text2") .on("dp.change", function (e) { find_text(); });
		});
	</script>

	<form name="form1" action="">

	<div class="row">
		<div class="col-12" align="left">

			<div class="d-inline-flex">
				<div class="input-group input-group-sm date" id="text1">
					<span class="input-group-text">날짜</span>
					<input type="text" name="text1" size="10" value="<?php echo e($text1); ?>" class="form-control" 
						onKeydown="if (event.keyCode == 13) { find_text(); }"> 
					<span class="input-group-text">
						<div class="input-group-addon">
							<i class="far fa-calendar-alt fa-lg"></i>
						</div>
					</span>
				</div>
			</div>
			-
			<div class="d-inline-flex">
				<div class="input-group input-group-sm date" id="text2">
					<input type="text" name="text2" size="10" value="<?php echo e($text2); ?>" class="form-control" 
						onKeydown="if (event.keyCode == 13) { find_text(); }"> 
					<span class="input-group-text">
						<div class="input-group-addon">
							<i class="far fa-calendar-alt fa-lg"></i>
						</div>
					</span>
				</div>
			</div>
			
		</div>
	</div>
	</form>

	<table class="table table-sm table-bordered table-hover mymargin5">
		<tr class="mycolor2">
			<td width="50%">제품명</td>
			<td width="50%">매출건수</td>
		</tr>

		<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td align="left"><?php echo e($row->product_name); ?></td>
				<td align="right"><?php echo e(number_format($row->cnumo)); ?></td>
		   </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<?php echo e($list->links( 'mypagination' )); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/best/index.blade.php ENDPATH**/ ?>