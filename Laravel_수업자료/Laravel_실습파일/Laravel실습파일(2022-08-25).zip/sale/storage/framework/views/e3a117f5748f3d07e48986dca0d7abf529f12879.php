
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">제품</div>

	<form name="form1" method="post" action="<?php echo e(route('product.update',$row->id)); ?><?php echo e($tmp); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>

	<table class="table table-sm table-bordered mymargin5">
		<tr>
			<td width="20%" class="mycolor2">번호</td>
			<td width="80%" align="left"><?php echo e($row->id); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 구분명</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<select name="gubuns_id" class="form-control form-control-sm">
						<option value="">선택하세요.</option>

				<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if( $row->gubuns_id == $row1->id ): ?>
						<option value="<?php echo e($row1->id); ?>" selected><?php echo e($row1->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($row1->id); ?>"><?php echo e($row1->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>
				</div>
			    <?php $__errorArgs = ['gubuns_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 제품명</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="name" size="20" maxlength="20" value="<?php echo e($row->name); ?>" class="form-control form-control-sm">
				</div>
			    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"> 단가</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="price" size="20" maxlength="20" value="<?php echo e($row->price); ?>" class="form-control form-control-sm">
				</div>
			    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"> 재고 </td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="jaego" size="20" maxlength="20" value="<?php echo e($row->jaego); ?>" class="form-control form-control-sm">
				</div>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"> 사진 </td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="file" name="pic" value="" class="form-control form-control-sm">
				</div>
				<br><br>
				<b>파일이름</b> : <?=$row->pic; ?><br>
			<?php if($row->pic): ?>
			   <img src="<?php echo e(asset('/storage/product_img/' . $row->pic)); ?>" width="200"	class="img-fluid img-thumbnail mymargin5">
			<?php else: ?>
				 <img src=" " width="200" height="150" class="img-fluid img-thumbnail mymargin5">
			<?php endif; ?>
			</td>
		</tr>	
	</table>

	<div align="center">
		<input type="submit" value="저장" class="btn btn-sm mycolor1">&nbsp;
		<input type="button" value="이전화면" class="btn btn-sm mycolor1" onClick="history.back();">
	</div>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/product/edit.blade.php ENDPATH**/ ?>