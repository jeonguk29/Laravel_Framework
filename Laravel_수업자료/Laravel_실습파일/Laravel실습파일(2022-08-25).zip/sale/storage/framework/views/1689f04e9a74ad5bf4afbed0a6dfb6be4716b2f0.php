
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">사용자</div>

	<form name="form1" method="post" action="<?php echo e(route('member.update',$row->id)); ?><?php echo e($tmp); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>

	<table class="table table-sm table-bordered mymargin5">
		<tr>
			<td width="20%" class="mycolor2">번호</td>
			<td width="80%" align="left"><?php echo e($row->id); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 이름</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="name" size="20" maxlength="20" value="<?php echo e($row->name); ?>" class="form-control form-control-sm">
				</div>
			    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 아이디</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="uid" size="20" maxlength="20" value="<?php echo e($row->uid); ?>" class="form-control form-control-sm">
				</div>
			    <?php $__errorArgs = ['uid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 암호</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="pwd" size="20" maxlength="20" value="<?php echo e($row->pwd); ?>" class="form-control form-control-sm">
				</div>
			    <?php $__errorArgs = ['pwd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
<?
	$tel1 = trim(substr($row->tel,0,3));
	$tel2 = trim(substr($row->tel,3,4));
	$tel3 = trim(substr($row->tel,7,4));
?>
		<tr>
			<td width="20%" class="mycolor2">전화</div></td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="tel1" size="3" maxlength="3" value="<?php echo e($tel1); ?>" class="form-control form-control-sm">-
					<input type="text" name="tel2" size="4" maxlength="4" value="<?php echo e($tel2); ?>" class="form-control form-control-sm">-
					<input type="text" name="tel3" size="4" maxlength="4" value="<?php echo e($tel3); ?>" class="form-control form-control-sm">
				</div>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">등급</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
<?php if($row->rank==0): ?>
				<input type="radio" name="rank" value="0" checked>&nbsp;직원&nbsp;&nbsp;
				<input type="radio" name="rank" value="1">&nbsp;관리자
<?php else: ?>
				<input type="radio" name="rank" value="0">&nbsp;직원&nbsp;&nbsp;
				<input type="radio" name="rank" value="1" checked>&nbsp;관리자
<?php endif; ?>
				</div>
			</td>
		</tr>
	</table>

	<div align="center">
		<input type="submit" value="저장" class="btn btn-sm mycolor1">&nbsp;
		<input type="button" value="이전화면" class="btn btn-sm mycolor1" onClick="history.back();">
	</div>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/member/edit.blade.php ENDPATH**/ ?>