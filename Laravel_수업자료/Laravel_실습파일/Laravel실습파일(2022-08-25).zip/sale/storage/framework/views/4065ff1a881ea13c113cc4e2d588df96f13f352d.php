
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">기간별 매출입 현황</div>

	<script>
		function find_text()
		{
			form1.action="<?php echo e(route('gigan.index')); ?>";
			form1.submit();
		}

		$(function() 
		{ 
			$("#text1") .datetimepicker({ 
				locale: "ko", 
				format: "YYYY-MM-DD" 
			}); 
			$("#text2") .datetimepicker({ 
				locale: "ko", 
				format: "YYYY-MM-DD" 
			});

			$("#text1") .on("dp.change", function (e) {	find_text(); });
			$("#text2") .on("dp.change", function (e) { find_text(); });
		});

		function make_excel()
		{
			form1.action="<?php echo e(url('gigan/excel')); ?>";
			form1.submit();
		}
	</script>

	<form name="form1" action="">

	<div class="row">
		<div class="col-12" align="left">

			<div class="d-inline-flex">
				<div class="input-group input-group-sm date" id="text1">
					<span class="input-group-text">날짜</span>
					<input type="text" name="text1" size="10" value="<?php echo e($text1); ?>" class="form-control" 
						onKeydown="if (event.keyCode == 13) { find_text(); }"> 
					<span class="input-group-text">
						<div class="input-group-addon">
							<i class="far fa-calendar-alt fa-lg"></i>
						</div>
					</span>
				</div>
			</div>
			-
			<div class="d-inline-flex">
				<div class="input-group input-group-sm date" id="text2">
					<input type="text" name="text2" size="10" value="<?php echo e($text2); ?>" class="form-control" 
						onKeydown="if (event.keyCode == 13) { find_text(); }"> 
					<span class="input-group-text">
						<div class="input-group-addon">
							<i class="far fa-calendar-alt fa-lg"></i>
						</div>
					</span>
				</div>
			</div>
			&nbsp;
			<div class="d-inline-flex">
				<div class="input-group input-group-sm">
					<span class="input-group-text">제품명</span>
					<select name="text3" class="form-select form-select-sm" onchange="find_text();">
						<option value="0" selected>전체</option>

				<?php $__currentLoopData = $list_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($row->id==$text3): ?>
						<option value='<?php echo e($row->id); ?>' selected><?php echo e($row->name); ?></option>
					<?php else: ?>
						<option value='<?php echo e($row->id); ?>'><?php echo e($row->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>
				</div>
			</div>
			<div class="d-inline-flex">
				<input type="button" value="EXCEL" class="form-control btn btn-sm mycolor1"
						onClick="if (confirm('엑셀파일로 저장할까요?')) make_excel();">
			</div>
		</div>
	</div>
	</form>

	<table class="table table-sm table-bordered table-hover mymargin5">
		<tr class="mycolor2">
			<td width="15%">날짜</td>
			<td width="25%">제품명</td>
			<td width="10%">단가</td>
			<td width="10%">매입수량</td>
			<td width="10%">매출수량</td>
			<td width="15%">금액</td>
			<td width="15%">비고</td>
		</tr>

		<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?
	$numi = $row->numi ? number_format($row->numi) : "";
	$numo = $row->numo ? number_format($row->numo) : "";
?>
			<tr>
				<td><?php echo e($row->writeday); ?></td>
				<td align="left"><?php echo e($row->product_name); ?></td>
				<td align="right"><?php echo e(number_format($row->price)); ?></td>
				<td align="right" class="mycolor3"><?php echo e($numi); ?></td>
				<td align="right" class="mycolor3"><?php echo e($numo); ?></td>
				<td align="right"><?php echo e(number_format($row->prices)); ?></td>
				<td align="left"><?php echo e($row->bigo); ?></td>
		   </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<?php echo e($list->links( 'mypagination' )); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/gigan/index.blade.php ENDPATH**/ ?>