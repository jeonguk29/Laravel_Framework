<!doctype html>
<html lang="kr">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>판매관리</title>
	<link   href="<?php echo e(asset('my/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link   href="<?php echo e(asset('my/css/my.css')); ?>" rel="stylesheet">
	<script src="<?php echo e(asset('my/js/jquery-3.6.0.min.js')); ?>"></script>
	<script src="<?php echo e(asset('my/js/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('my/js/bootstrap.min.js')); ?>"></script>

	<script src="<?php echo e(asset('my/js/moment-with-locales.min.js')); ?>"></script>
	<script src="<?php echo e(asset('my/js/bootstrap5-datetimepicker.js')); ?>"></script>
	<link   href="<?php echo e(asset('my/css/bootstrap5-datetimepicker.css')); ?>" rel="stylesheet">
	<link   href="<?php echo e(asset('my/css/all.min.css')); ?>" rel="stylesheet" >
</head>
<body>

<div class="container">


<!-------------------------------------------------------------->
<!-- 시작 : Content                                                                  -->
<!-------------------------------------------------------------->

	<?php echo $__env->yieldContent("content"); ?>

<!-------------------------------------------------------------->
<!-- 끝 : Content                                                                     -->
<!-------------------------------------------------------------->
</div>

</body>
</html>

<?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/main_nomenu.blade.php ENDPATH**/ ?>