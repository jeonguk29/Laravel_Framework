
<?php $__env->startSection('content'); ?>

<?
	$tel1 = trim(substr($row->tel,0,3));
	$tel2 = trim(substr($row->tel,3,4));
	$tel3 = trim(substr($row->tel,7,4));
	$tel = $tel1 . "-" . $tel2 . "-" . $tel3;
	$rank = $row->rank==0 ? '직원' : '관리자';
?>

	<br>
	<div class="alert mycolor1" role="alert">사용자</div>

	<form name="form1" method="post" action="">

	<table class="table table-sm table-bordered mymargin5">
		<tr>
			<td width="20%" class="mycolor2">번호</td>
			<td width="80%" align="left"><?php echo e($row->id); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 이름</td>
			<td width="80%" align="left"><?php echo e($row->name); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 아이디</td>
			<td width="80%" align="left"><?php echo e($row->uid); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 암호</td>
			<td width="80%" align="left"><?php echo e($row->pwd); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">전화</div></td>
			<td width="80%" align="left"><?php echo e($tel); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">등급</td>
			<td width="80%" align="left"><?php echo e($rank); ?></td>
		</tr>
	</table>

	<div align="center">
		<a href="<?php echo e(route('member.edit', $row->id)); ?><?php echo e($tmp); ?>" class="btn btn-sm mycolor1">수정</a>
		<form action="<?php echo e(route('member.destroy', $row->id)); ?>">
			<?php echo csrf_field(); ?>
			<?php echo method_field('DELETE'); ?>
			<button type="submit" class="btn btn-sm mycolor1" 
				onClick="return confirm('삭제할까요 ?');">삭제</button> &nbsp;
		</form>
		<input type="button" value="이전화면" class="btn btn-sm mycolor1" onClick="history.back();">
	</div>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/member/show.blade.php ENDPATH**/ ?>